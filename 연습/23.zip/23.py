import random
count =0 
input_list =[]
num =["하나","둘","셋"]
while count <=2:
    while True:
        input_value = input(f"{num[count]}번쨰 입력하세요 :")
    # 글자범위 5<= =>20 else 범위 재요구
        if 3 <=len(input_value) <=20:
            input_list.append(input_value) 
            count+=1
            break
        else:
            print("재입력 구다사이")
            break

com_random = random.choice(input_list)     
print(f"단어 선택 완료게임을 시작합니다: {com_random}") 
num =0
    #랜덤값을 반올림 and 반 
if len(com_random) % 2==0:
    num+=len(com_random) //2
else:
    num+=len(com_random) // 2 +1

#블라인드 
asap = []
b = 0
for i in com_random:
    asap += i

# asap = 단어 쪼갠거


a=[]
while b < num:
    randomhaha=random.randint(0,len(com_random)-1)
    if randomhaha not in a:
        a.append(randomhaha)
        b += 1


    
#-추가
for q in a: # a = 1 2 3
    asap[q] = "_" # =오른쪽의 값을 왼쪽에 대입하겠다


#list에있는값을 뽑아주기
blind_word = ""
for i in asap:
    
    blind_word+=i
print(blind_word)
count=1
while True:
    dano = 0
    a = 0
    print(f"{count}번쨰 시도, 아래 단어를 구성하는 알파벳 하나 입력하시던지 ")
    print(blind_word)
    input_user =input()
    #만약 input_user가 포함안한다면 단어 노포함
    if input_user not in com_random:
        print("노포함 다시 쓰셈")
        
    #혹시포함하면 포함하는숫자 알려줌 그리고blind_word추가 
    else:
        for  index in a:
           if  asap[index] == input_user:
               blind_word[index] = input_user
            
            
                
            
      
                
                
                
                
                        
    # if blind_word == com_random:
    #     print("clear -선택")
    #     break
                    
    # #포함하는 글자가 포함 횟수랑 그만큼 추가 
    #다맞추면 선택단어 총 시도 횟수 나와야함 
    

    



                